# Arquitetura

O fluxo de uma requisição é: `api -> services -> domain/repositories`.

- `api`: converte HTTP para DTOs e respostas; não contém regra de negócio ou SQL.
- `services`: orquestra casos de uso e transações; recebe dependências por injeção.
- `domain`: lógica determinística e independente de Flask, banco e rede.
- `repositories`: única camada que conhece SQL Server e executa SQL parametrizado.
- `templates/static`: apresentam dados já preparados pelo caso de uso; não decidem regra de negócio.

Uma mudança que cruza camadas deve ter teste no menor nível que prove seu comportamento. Prefira teste unitário; use integração para contrato de banco/API e E2E apenas para fluxos críticos.