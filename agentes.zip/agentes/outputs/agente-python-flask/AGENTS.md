# Regras do agente

## Objetivo
Desenvolver e refatorar esta aplicação Flask, SQL Server e HTML/CSS/JavaScript com mudanças pequenas, testadas e fáceis de revisar.

## Processo obrigatório
- Antes de alterar código, leia `README.md`, `docs/architecture.md` e os testes relacionados.
- Para tarefas não triviais, apresente plano curto, arquivos afetados e riscos antes de editar.
- Preserve comportamento em refactors; escreva testes de caracterização quando a cobertura não existir.
- Ao concluir, execute `make check` e informe comandos executados, resultado e pendências.

## Código Python e Flask
- Use Python 3.12+, type hints explícitos e `ruff` para lint/formatação.
- Funções têm uma responsabilidade e normalmente até 30 linhas; módulos até 400 linhas.
- Prefira nomes específicos e pesquisáveis. Nunca crie `utils.py`, `helpers.py`, `data`, `manager` ou `handler` genéricos.
- Rotas e blueprints só lidam com HTTP. Regras vivem em `domain/` e `services/`; SQL vive somente em `repositories/`.
- Injete dependências por parâmetros/factories. Não instancie clientes externos dentro da regra de negócio.
- Exceções devem incluir contexto seguro: operação, identificador e formato esperado; não registre segredos.

## SQL Server e segurança
- Use queries parametrizadas; nunca concatene entrada do usuário em SQL.
- Defina transação, commit e rollback explicitamente para escritas.
- Credenciais vêm de variáveis de ambiente; nunca entram em código, `.env` versionado ou logs.
- Migrações são versionadas e reversíveis quando possível.

## Front-end
- HTML semântico, labels associados a inputs, foco visível e teclado funcional.
- Não use CSS ou JavaScript inline. Organize páginas/componentes em arquivos previsíveis.
- Toda tela trata estados: carregando, vazio, erro e sucesso.
- Reutilize componentes e tokens CSS; não copie blocos de estilo ou regras de UI.

## Comentários e documentação
- Comentários explicam o PORQUÊ: regra de negócio, incidente, ADR, issue ou limitação externa.
- Preserve comentários de proveniência durante refactors.
- APIs públicas recebem docstring com intenção, entradas/saídas e exemplo quando não forem óbvias.

## Testes e GitHub
- Toda feature nova recebe teste; todo bug recebe teste de regressão.
- Mocke I/O externo com fakes nomeados, não com stubs inline frágeis.
- Um assunto por branch e por PR. Commits: `feat:`, `fix:`, `refactor:`, `test:`, `docs:`.
- PR descreve objetivo, impacto, testes e risco/rollback.