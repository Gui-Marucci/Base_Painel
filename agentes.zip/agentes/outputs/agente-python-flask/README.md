# Starter: agente Python, Flask e SQL Server

Este repositório é uma base para um agente de desenvolvimento que cria páginas, implementa APIs e refatora com segurança.

## Início rápido

1. Copie `.env.example` para `.env` e preencha apenas no ambiente local.
2. Crie o ambiente Python e instale dependências: `python -m pip install -e ".[dev]"`.
3. Instale dependências do front-end: `npm install`.
4. Rode `make check` antes de enviar alterações.

## Comandos que o agente deve usar

| Comando | Finalidade |
| --- | --- |
| `make format` | Formata Python, CSS/HTML/JS |
| `make lint` | Executa lint estático |
| `make typecheck` | Verifica tipos Python |
| `make test` | Executa testes |
| `make check` | Executa toda a validação |

## Estrutura

```text
app/
  api/            # blueprints, HTTP e schemas
  domain/         # entidades e regras puras
  services/       # casos de uso
  repositories/   # SQL Server e persistência
  templates/      # páginas Jinja e componentes
  static/css/     # estilos por componente/página
  static/js/      # comportamento do navegador
docs/
  architecture.md # limites entre camadas
  decisions/      # ADRs: decisão e motivo
tests/
  unit/           # domínio e services
  integration/    # Flask, banco e adaptadores
  e2e/            # fluxos críticos de interface
```

Leia `AGENTS.md` antes de pedir mudanças ao agente. Para uma feature, descreva objetivo, usuários/permissões, campos, origem dos dados, estados de UI e critério de aceite.